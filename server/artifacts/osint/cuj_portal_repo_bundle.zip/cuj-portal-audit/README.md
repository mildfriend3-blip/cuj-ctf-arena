# CUJ Student Portal Config
Internal deployment templates.
